//
//  Shell.h
//  FrameShellTest
//
//  Created by guodong on 16/1/2.
//  Copyright © 2016年 nonobank. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Shell : NSObject
-(void)add:(int)a :(int)b;
@end
